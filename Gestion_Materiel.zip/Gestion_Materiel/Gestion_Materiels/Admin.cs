﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Gestion_Materiels
{
    public partial class Admin : Form
    {
        // Connexion à la base de données
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\USERS\FOUAD\ONEDRIVE\المستندات\MATERIEL_SPORTIF.MDF;Integrated Security=True;Connect Timeout=30");

        public Admin()
        {
            InitializeComponent();
            // Appeler la méthode LoadDemandes lorsque le formulaire est initialisé
            LoadDemandes();
        }

        // Charger les données des demandes dans le DataGridView
        private void LoadDemandes()
        {
            try
            {
                con.Open();
                MessageBox.Show("Connexion ouverte", "Débogage", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Requête SQL pour récupérer les données
                SqlDataAdapter da = new SqlDataAdapter(
                    "SELECT d.id_demande, u.username, d.date_demande, d.date_debut, d.date_fin, d.statut_demande, d.nom_equipement " +
                    "FROM Demandes d JOIN Utilisateurs u ON d.id_utilisateur = u.id_utilisateur", con);

                DataTable dt = new DataTable();
                da.Fill(dt);

                // Afficher le nombre de lignes récupérées pour débogage
                MessageBox.Show($"Nombre de lignes récupérées : {dt.Rows.Count}", "Débogage", MessageBoxButtons.OK, MessageBoxIcon.Information);

                if (dt.Rows.Count > 0)
                {
                    // Lier les données au DataGridView
                    dataGridView1.DataSource = dt;
                }
                else
                {
                    MessageBox.Show("Aucune demande trouvée.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                // Afficher un message d'erreur si la connexion échoue
                MessageBox.Show($"Erreur de chargement des données : {ex.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                con.Close(); // Toujours fermer la connexion après l'utilisation
            }
        }

        // Méthode appelée lorsque l'utilisateur clique sur une cellule dans le DataGridView
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Vérifier si l'utilisateur a cliqué sur une ligne, pas sur l'en-tête
            {
                // Créer un menu contextuel avec les options "Accepter", "Refuser", "Supprimer"
                ContextMenuStrip menu = new ContextMenuStrip();
                menu.Items.Add("Accepter", null, new EventHandler(Accepter_Click));
                menu.Items.Add("Refuser", null, new EventHandler(Refuser_Click));
                menu.Items.Add("Supprimer", null, new EventHandler(Supprimer_Click));

                // Affecter l'index de la ligne sélectionnée au menu
                menu.Tag = e.RowIndex;

                // Afficher le menu contextuel à la position du curseur
                menu.Show(Cursor.Position);
            }
        }

        // Méthode appelée lorsque l'utilisateur clique sur "Accepter"
        private void Accepter_Click(object sender, EventArgs e)
        {
            int rowIndex = (int)((ContextMenuStrip)((ToolStripMenuItem)sender).Owner).Tag;
            int idDemande = Convert.ToInt32(dataGridView1.Rows[rowIndex].Cells["id_demande"].Value);

            // Mettre à jour le statut de la demande à "Validée"
            UpdateStatutDemande(idDemande, "Validée");
        }

        // Méthode appelée lorsque l'utilisateur clique sur "Refuser"
        private void Refuser_Click(object sender, EventArgs e)
        {
            int rowIndex = (int)((ContextMenuStrip)((ToolStripMenuItem)sender).Owner).Tag;
            int idDemande = Convert.ToInt32(dataGridView1.Rows[rowIndex].Cells["id_demande"].Value);

            // Mettre à jour le statut de la demande à "Refusée"
            UpdateStatutDemande(idDemande, "Refusée");
        }

        // Méthode appelée lorsque l'utilisateur clique sur "Supprimer"
        private void Supprimer_Click(object sender, EventArgs e)
        {
            int rowIndex = (int)((ContextMenuStrip)((ToolStripMenuItem)sender).Owner).Tag;
            int idDemande = Convert.ToInt32(dataGridView1.Rows[rowIndex].Cells["id_demande"].Value);

            // Supprimer la demande
            DeleteDemande(idDemande);
        }

        // Méthode pour mettre à jour le statut d'une demande dans la base de données
        private void UpdateStatutDemande(int idDemande, string statut)
        {
            try
            {
                con.Open();

                // Commande SQL pour mettre à jour le statut de la demande
                SqlCommand cmd = new SqlCommand("UPDATE Demandes SET statut_demande = @statut WHERE id_demande = @idDemande", con);
                cmd.Parameters.AddWithValue("@statut", statut);
                cmd.Parameters.AddWithValue("@idDemande", idDemande);
                cmd.ExecuteNonQuery();

                // Recharger les données après la mise à jour
                LoadDemandes();

                MessageBox.Show($"Demande {statut}", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors de la mise à jour : {ex.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                con.Close();
            }
        }

        // Méthode pour supprimer une demande de la base de données
        private void DeleteDemande(int idDemande)
        {
            try
            {
                con.Open();

                // Commande SQL pour supprimer une demande
                SqlCommand cmd = new SqlCommand("DELETE FROM Demandes WHERE id_demande = @idDemande", con);
                cmd.Parameters.AddWithValue("@idDemande", idDemande);
                cmd.ExecuteNonQuery();

                // Recharger les données après la suppression
                LoadDemandes();

                MessageBox.Show("Demande supprimée", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur lors de la suppression : {ex.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                con.Close();
            }
        }
    }
}
