﻿namespace Gestion_Materiels
{
    partial class vos_demandes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Dèconnection = new System.Windows.Forms.Button();
            this.infoLabel = new System.Windows.Forms.Label();
            this.gESTION_MATÉRIEL_SPORTIFDataSet = new Gestion_Materiels.GESTION_MATÉRIEL_SPORTIFDataSet();
            this.gESTIONMATÉRIELSPORTIFDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.equipementsBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.equipementsTableAdapter = new Gestion_Materiels.GESTION_MATÉRIEL_SPORTIFDataSetTableAdapters.EquipementsTableAdapter();
            this.reserver = new System.Windows.Forms.Button();
            this.equipementsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iddemandeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idutilisateurDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datedemandeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datedebutDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datefinDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statutdemandeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idequipementDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomequipementDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.demandesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mATERIEL_SPORTIFDataSet1 = new Gestion_Materiels.MATERIEL_SPORTIFDataSet1();
            this.empruntsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mATERIEL_SPORTIFDataSet = new Gestion_Materiels.MATERIEL_SPORTIFDataSet();
            this.empruntsTableAdapter = new Gestion_Materiels.MATERIEL_SPORTIFDataSetTableAdapters.EmpruntsTableAdapter();
            this.mATERIELSPORTIFDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.demandesTableAdapter = new Gestion_Materiels.MATERIEL_SPORTIFDataSet1TableAdapters.DemandesTableAdapter();
            this.x = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.gESTION_MATÉRIEL_SPORTIFDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gESTIONMATÉRIELSPORTIFDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.equipementsBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.equipementsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.demandesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mATERIEL_SPORTIFDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.empruntsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mATERIEL_SPORTIFDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mATERIELSPORTIFDataSetBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // Dèconnection
            // 
            this.Dèconnection.Location = new System.Drawing.Point(575, 275);
            this.Dèconnection.Name = "Dèconnection";
            this.Dèconnection.Size = new System.Drawing.Size(112, 33);
            this.Dèconnection.TabIndex = 19;
            this.Dèconnection.Text = "Dèconnection";
            this.Dèconnection.UseVisualStyleBackColor = true;
            this.Dèconnection.Click += new System.EventHandler(this.Dèconnection_Click);
            // 
            // infoLabel
            // 
            this.infoLabel.AutoSize = true;
            this.infoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.infoLabel.Location = new System.Drawing.Point(128, 16);
            this.infoLabel.Name = "infoLabel";
            this.infoLabel.Size = new System.Drawing.Size(136, 20);
            this.infoLabel.TabIndex = 14;
            this.infoLabel.Text = "Vos Demandes";
            // 
            // gESTION_MATÉRIEL_SPORTIFDataSet
            // 
            this.gESTION_MATÉRIEL_SPORTIFDataSet.DataSetName = "GESTION_MATÉRIEL_SPORTIFDataSet";
            this.gESTION_MATÉRIEL_SPORTIFDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // gESTIONMATÉRIELSPORTIFDataSetBindingSource
            // 
            this.gESTIONMATÉRIELSPORTIFDataSetBindingSource.DataSource = this.gESTION_MATÉRIEL_SPORTIFDataSet;
            this.gESTIONMATÉRIELSPORTIFDataSetBindingSource.Position = 0;
            // 
            // equipementsBindingSource1
            // 
            this.equipementsBindingSource1.DataMember = "Equipements";
            this.equipementsBindingSource1.DataSource = this.gESTIONMATÉRIELSPORTIFDataSetBindingSource;
            // 
            // equipementsTableAdapter
            // 
            this.equipementsTableAdapter.ClearBeforeFill = true;
            // 
            // reserver
            // 
            this.reserver.Location = new System.Drawing.Point(132, 275);
            this.reserver.Name = "reserver";
            this.reserver.Size = new System.Drawing.Size(100, 33);
            this.reserver.TabIndex = 17;
            this.reserver.UseVisualStyleBackColor = true;
            this.reserver.Click += new System.EventHandler(this.reserver_Click);
            // 
            // equipementsBindingSource
            // 
            this.equipementsBindingSource.DataMember = "Equipements";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iddemandeDataGridViewTextBoxColumn,
            this.idutilisateurDataGridViewTextBoxColumn,
            this.datedemandeDataGridViewTextBoxColumn,
            this.datedebutDataGridViewTextBoxColumn,
            this.datefinDataGridViewTextBoxColumn,
            this.statutdemandeDataGridViewTextBoxColumn,
            this.idequipementDataGridViewTextBoxColumn,
            this.nomequipementDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.demandesBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(66, 82);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(644, 150);
            this.dataGridView1.TabIndex = 20;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // iddemandeDataGridViewTextBoxColumn
            // 
            this.iddemandeDataGridViewTextBoxColumn.DataPropertyName = "id_demande";
            this.iddemandeDataGridViewTextBoxColumn.HeaderText = "id_demande";
            this.iddemandeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.iddemandeDataGridViewTextBoxColumn.Name = "iddemandeDataGridViewTextBoxColumn";
            this.iddemandeDataGridViewTextBoxColumn.ReadOnly = true;
            this.iddemandeDataGridViewTextBoxColumn.Width = 125;
            // 
            // idutilisateurDataGridViewTextBoxColumn
            // 
            this.idutilisateurDataGridViewTextBoxColumn.DataPropertyName = "id_utilisateur";
            this.idutilisateurDataGridViewTextBoxColumn.HeaderText = "id_utilisateur";
            this.idutilisateurDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.idutilisateurDataGridViewTextBoxColumn.Name = "idutilisateurDataGridViewTextBoxColumn";
            this.idutilisateurDataGridViewTextBoxColumn.Width = 125;
            // 
            // datedemandeDataGridViewTextBoxColumn
            // 
            this.datedemandeDataGridViewTextBoxColumn.DataPropertyName = "date_demande";
            this.datedemandeDataGridViewTextBoxColumn.HeaderText = "date_demande";
            this.datedemandeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.datedemandeDataGridViewTextBoxColumn.Name = "datedemandeDataGridViewTextBoxColumn";
            this.datedemandeDataGridViewTextBoxColumn.Width = 125;
            // 
            // datedebutDataGridViewTextBoxColumn
            // 
            this.datedebutDataGridViewTextBoxColumn.DataPropertyName = "date_debut";
            this.datedebutDataGridViewTextBoxColumn.HeaderText = "date_debut";
            this.datedebutDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.datedebutDataGridViewTextBoxColumn.Name = "datedebutDataGridViewTextBoxColumn";
            this.datedebutDataGridViewTextBoxColumn.Width = 125;
            // 
            // datefinDataGridViewTextBoxColumn
            // 
            this.datefinDataGridViewTextBoxColumn.DataPropertyName = "date_fin";
            this.datefinDataGridViewTextBoxColumn.HeaderText = "date_fin";
            this.datefinDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.datefinDataGridViewTextBoxColumn.Name = "datefinDataGridViewTextBoxColumn";
            this.datefinDataGridViewTextBoxColumn.Width = 125;
            // 
            // statutdemandeDataGridViewTextBoxColumn
            // 
            this.statutdemandeDataGridViewTextBoxColumn.DataPropertyName = "statut_demande";
            this.statutdemandeDataGridViewTextBoxColumn.HeaderText = "statut_demande";
            this.statutdemandeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.statutdemandeDataGridViewTextBoxColumn.Name = "statutdemandeDataGridViewTextBoxColumn";
            this.statutdemandeDataGridViewTextBoxColumn.Width = 125;
            // 
            // idequipementDataGridViewTextBoxColumn
            // 
            this.idequipementDataGridViewTextBoxColumn.DataPropertyName = "id_equipement";
            this.idequipementDataGridViewTextBoxColumn.HeaderText = "id_equipement";
            this.idequipementDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.idequipementDataGridViewTextBoxColumn.Name = "idequipementDataGridViewTextBoxColumn";
            this.idequipementDataGridViewTextBoxColumn.Width = 125;
            // 
            // nomequipementDataGridViewTextBoxColumn
            // 
            this.nomequipementDataGridViewTextBoxColumn.DataPropertyName = "nom_equipement";
            this.nomequipementDataGridViewTextBoxColumn.HeaderText = "nom_equipement";
            this.nomequipementDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.nomequipementDataGridViewTextBoxColumn.Name = "nomequipementDataGridViewTextBoxColumn";
            this.nomequipementDataGridViewTextBoxColumn.Width = 125;
            // 
            // demandesBindingSource
            // 
            this.demandesBindingSource.DataMember = "Demandes";
            this.demandesBindingSource.DataSource = this.mATERIEL_SPORTIFDataSet1;
            // 
            // mATERIEL_SPORTIFDataSet1
            // 
            this.mATERIEL_SPORTIFDataSet1.DataSetName = "MATERIEL_SPORTIFDataSet1";
            this.mATERIEL_SPORTIFDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // empruntsBindingSource
            // 
            this.empruntsBindingSource.DataMember = "Emprunts";
            this.empruntsBindingSource.DataSource = this.mATERIEL_SPORTIFDataSet;
            // 
            // mATERIEL_SPORTIFDataSet
            // 
            this.mATERIEL_SPORTIFDataSet.DataSetName = "MATERIEL_SPORTIFDataSet";
            this.mATERIEL_SPORTIFDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // empruntsTableAdapter
            // 
            this.empruntsTableAdapter.ClearBeforeFill = true;
            // 
            // mATERIELSPORTIFDataSetBindingSource
            // 
            this.mATERIELSPORTIFDataSetBindingSource.DataSource = this.mATERIEL_SPORTIFDataSet;
            this.mATERIELSPORTIFDataSetBindingSource.Position = 0;
            // 
            // demandesTableAdapter
            // 
            this.demandesTableAdapter.ClearBeforeFill = true;
            // 
            // x
            // 
            this.x.AutoSize = true;
            this.x.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.x.Location = new System.Drawing.Point(766, 9);
            this.x.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.x.Name = "x";
            this.x.Size = new System.Drawing.Size(21, 20);
            this.x.TabIndex = 33;
            this.x.Text = "X";
            this.x.Click += new System.EventHandler(this.x_Click);
            // 
            // vos_demandes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.x);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.Dèconnection);
            this.Controls.Add(this.infoLabel);
            this.Controls.Add(this.reserver);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "vos_demandes";
            this.Text = "vos_demande";
            this.Load += new System.EventHandler(this.vos_demandes_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gESTION_MATÉRIEL_SPORTIFDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gESTIONMATÉRIELSPORTIFDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.equipementsBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.equipementsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.demandesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mATERIEL_SPORTIFDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.empruntsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mATERIEL_SPORTIFDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mATERIELSPORTIFDataSetBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Dèconnection;
        private System.Windows.Forms.Label infoLabel;
        private System.Windows.Forms.BindingSource equipementsBindingSource;
        private GESTION_MATÉRIEL_SPORTIFDataSet gESTION_MATÉRIEL_SPORTIFDataSet;
        private System.Windows.Forms.BindingSource gESTIONMATÉRIELSPORTIFDataSetBindingSource;
        private System.Windows.Forms.BindingSource equipementsBindingSource1;
        private GESTION_MATÉRIEL_SPORTIFDataSetTableAdapters.EquipementsTableAdapter equipementsTableAdapter;
        private System.Windows.Forms.Button reserver;
        private System.Windows.Forms.DataGridView dataGridView1;
        private MATERIEL_SPORTIFDataSet mATERIEL_SPORTIFDataSet;
        private System.Windows.Forms.BindingSource empruntsBindingSource;
        private MATERIEL_SPORTIFDataSetTableAdapters.EmpruntsTableAdapter empruntsTableAdapter;
        private System.Windows.Forms.BindingSource mATERIELSPORTIFDataSetBindingSource;
        private MATERIEL_SPORTIFDataSet1 mATERIEL_SPORTIFDataSet1;
        private System.Windows.Forms.BindingSource demandesBindingSource;
        private MATERIEL_SPORTIFDataSet1TableAdapters.DemandesTableAdapter demandesTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iddemandeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idutilisateurDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn datedemandeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn datedebutDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn datefinDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statutdemandeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idequipementDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomequipementDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label x;
    }
}