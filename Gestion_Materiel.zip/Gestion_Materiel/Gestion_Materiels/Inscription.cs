﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using Gestion_Materiel;

namespace Gestion_Materiels
{
    public partial class Inscription : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\USERS\FOUAD\ONEDRIVE\المستندات\MATERIEL_SPORTIF.MDF;Integrated Security=True;Connect Timeout=30");

        public Inscription()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void ReturnButton_Click(object sender, EventArgs e)
        {

        }

        private void CreateButton_Click(object sender, EventArgs e)
        {

        }

        private void Inscription_Load(object sender, EventArgs e)
        {

        }

        private void ReturnButton_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Connection Connection = new Connection();
            Connection.Show();
        }

        private void x_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void CreateButton_Click_1(object sender, EventArgs e)
        {
            if (EmailBox.Text == "" || UsernameBox.Text == "" || PasswordBox.Text == "")
            {
                MessageBox.Show("Veuillez remplir tous les champs");
                return;
            }

            string email = EmailBox.Text.Trim();
            string password = PasswordBox.Text.Trim();

            // Vérification si l'email est valide
            if (!IsValidEmail(email))
            {
                MessageBox.Show("Veuillez entrer un email valide.");
                return;
            }

            // Vérification si le mot de passe est valide
            if (!IsValidPassword(password))
            {
                MessageBox.Show("Le mot de passe doit contenir au minimum une majuscule, une minuscule, un caractère spécial et doit avoir une longueur d'au moins 8 caractères.");
                return;
            }

            con.Open();

            // Vérification si l'email existe déjà dans la base de données
            SqlCommand checkEmailCmd = new SqlCommand("SELECT COUNT(*) FROM Utilisateurs WHERE email = @Email", con);
            checkEmailCmd.Parameters.AddWithValue("@Email", email);
            int emailExists = (int)checkEmailCmd.ExecuteScalar();

            if (emailExists > 0)
            {
                MessageBox.Show("Un compte existe déjà avec cet email.");
                con.Close();
                return;
            }

            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "INSERT INTO Utilisateurs (email, username, mot_de_passe) VALUES (@Email, @Username, @Password)";
            cmd.Parameters.AddWithValue("@Email", email);
            cmd.Parameters.AddWithValue("@Username", UsernameBox.Text.Trim());
            cmd.Parameters.AddWithValue("@Password", password);

            cmd.ExecuteNonQuery();
            con.Close();

            MessageBox.Show("Votre inscription est terminée.");
            this.Hide();
            Connection loginForm = new Connection();
            loginForm.Show();
        }

        // Fonction pour valider l'email avec une expression régulière
        private bool IsValidEmail(string email)
        {
            
            string emailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            return Regex.IsMatch(email, emailPattern);
        }

        // Fonction pour valider le mot de passe
        private bool IsValidPassword(string password)
        {
            if (password.Length < 8)
                return false;

            bool hasUpper = password.Any(char.IsUpper);
            bool hasLower = password.Any(char.IsLower);
            bool hasSpecial = password.Any(ch => !char.IsLetterOrDigit(ch));

            return hasUpper && hasLower && hasSpecial;
        }

        private void PasswordBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
