﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Windows.Forms;
using Gestion_Materiel;

namespace Gestion_Materiels
{
    public partial class Emprunts : Form
    {
        private string selectedEquipement;

        public Emprunts(string selectedEquipement = null)
        {
            InitializeComponent();
            this.selectedEquipement = selectedEquipement;
        }

        private void Emprunts_Load(object sender, EventArgs e)
        {
            // Charger les catégories dans la ComboBox au chargement du formulaire
            LoadCategories();

            // Lier l'événement SelectedIndexChanged de Categorie
            Categorie.SelectedIndexChanged += Categorie_SelectedIndexChanged;

            // Limiter le choix de la première date dans le DateTimePicker
            DateTime aujourdhui = DateTime.Now;
            DateTime deuxMoisPlusTard = aujourdhui.AddMonths(2);

            dateTimePicker1.MinDate = aujourdhui;
            dateTimePicker1.MaxDate = deuxMoisPlusTard;

            dateTimePicker1.ValueChanged += dateTimePicker1_ValueChanged;
            dateTimePicker2.ValueChanged += dateTimePicker2_ValueChanged;

            // Sélectionner l'élément passé en paramètre
            if (!string.IsNullOrEmpty(selectedEquipement) && Materiel.Items.Contains(selectedEquipement))
            {
                Materiel.SelectedItem = selectedEquipement;
            }

            // Lier l'événement SelectedIndexChanged de Materiel
            Materiel.SelectedIndexChanged += Materiel_SelectedIndexChanged;
        }

        private void Materiel_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Vérifiez si un équipement est sélectionné
            string selectedEquipement = Materiel.SelectedItem?.ToString();
            if (string.IsNullOrEmpty(selectedEquipement))
            {
                MessageBox.Show("Veuillez sélectionner un équipement.");
            }
            else
            {
                // Logique après avoir sélectionné un équipement
                MessageBox.Show("Équipement sélectionné : " + selectedEquipement);
            }
        }

        private void LoadCategories()
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\USERS\FOUAD\ONEDRIVE\المستندات\MATERIEL_SPORTIF.MDF;Integrated Security=True;Connect Timeout=30");

            try
            {
                con.Open(); // Ouvre la connexion à la base de données

                string query = "SELECT nom_categorie FROM categorie";
                SqlDataAdapter adapter = new SqlDataAdapter(query, con);

                DataTable dt = new DataTable();
                adapter.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    Categorie.Items.Clear();
                    foreach (DataRow row in dt.Rows)
                    {
                        Categorie.Items.Add(row["nom_categorie"].ToString());
                    }
                }
                else
                {
                    MessageBox.Show("Aucune catégorie trouvée.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur : " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void Categorie_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Categorie.SelectedItem != null)
            {
                string selectedCategorie = Categorie.SelectedItem.ToString();
                LoadEquipementsByCategorie(selectedCategorie);
            }
        }

        private void LoadEquipementsByCategorie(string nomCategorie)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\USERS\FOUAD\ONEDRIVE\المستندات\MATERIEL_SPORTIF.MDF;Integrated Security=True;Connect Timeout=30");

            try
            {
                con.Open();

                string query = "SELECT nom FROM Equipements WHERE id_categorie IN (SELECT id_categorie FROM categorie WHERE nom_categorie = @nomCategorie)";
                SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                adapter.SelectCommand.Parameters.AddWithValue("@nomCategorie", nomCategorie);

                DataTable dt = new DataTable();
                adapter.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    Materiel.Items.Clear();
                    foreach (DataRow row in dt.Rows)
                    {
                        Materiel.Items.Add(row["nom"].ToString());
                    }
                }
                else
                {
                    MessageBox.Show("Aucun équipement trouvé pour cette catégorie.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de la récupération des équipements : " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            DateTime dateSelectionnee = dateTimePicker1.Value;
            DateTime deuxMoisPlusTard = dateSelectionnee.AddMonths(2);

            dateTimePicker2.MinDate = dateSelectionnee;
            dateTimePicker2.MaxDate = deuxMoisPlusTard;

            if (dateTimePicker2.Value < dateSelectionnee)
            {
                dateTimePicker2.Value = dateSelectionnee;
            }
            else if (dateTimePicker2.Value > deuxMoisPlusTard)
            {
                dateTimePicker2.Value = deuxMoisPlusTard;
            }
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
            DateTime dateSelectionnee1 = dateTimePicker1.Value;
            DateTime deuxMoisPlusTard = dateSelectionnee1.AddMonths(2);

            if (dateTimePicker2.Value < dateSelectionnee1)
            {
                dateTimePicker2.Value = dateSelectionnee1;
            }
            else if (dateTimePicker2.Value > deuxMoisPlusTard)
            {
                dateTimePicker2.Value = deuxMoisPlusTard;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Récupérer l'équipement sélectionné
            string selectedEquipement = Materiel.SelectedItem?.ToString();
            if (string.IsNullOrEmpty(selectedEquipement))
            {
                MessageBox.Show("Veuillez sélectionner un équipement.");
                return;
            }

            // Vérifier les dates de prêt
            DateTime dateDebut = dateTimePicker1.Value;
            DateTime dateFin = dateTimePicker2.Value;

            if (dateFin <= dateDebut)
            {
                MessageBox.Show("La date de fin doit être après la date de début.");
                return;
            }

            // Utiliser Global.idutilisateur pour obtenir l'ID de l'utilisateur connecté
            int idUtilisateur = Global.idutilisateur;

            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\USERS\FOUAD\ONEDRIVE\المستندات\MATERIEL_SPORTIF.MDF;Integrated Security=True;Connect Timeout=30");

            try
            {
                con.Open(); // Ouvrir la connexion à la base de données

                // Récupérer l'ID et le nom de l'équipement à partir du nom
                string getEquipementDetailsQuery = "SELECT id_equipement, nom FROM Equipements WHERE nom = @nomEquipement";
                SqlCommand getEquipementDetailsCmd = new SqlCommand(getEquipementDetailsQuery, con);
                getEquipementDetailsCmd.Parameters.AddWithValue("@nomEquipement", selectedEquipement);
                SqlDataReader reader = getEquipementDetailsCmd.ExecuteReader();

                if (!reader.Read())
                {
                    MessageBox.Show("L'équipement sélectionné n'existe pas.");
                    return;
                }

                int idEquipement = (int)reader["id_equipement"];
                string nomEquipement = reader["nom"].ToString();
                reader.Close(); // Fermer le reader après avoir récupéré les données

                // Insérer la demande d'emprunt
                string insertQuery = "INSERT INTO Demandes (id_equipement, nom_equipement, id_utilisateur, date_demande, date_debut, date_fin, statut_demande) " +
                                     "VALUES (@idEquipement, @nomEquipement, @idUtilisateur, @dateDemande, @dateDebut, @dateFin, 'en attente')";

                SqlCommand insertCmd = new SqlCommand(insertQuery, con);

                insertCmd.Parameters.AddWithValue("@idEquipement", idEquipement);
                insertCmd.Parameters.AddWithValue("@nomEquipement", nomEquipement);
                insertCmd.Parameters.AddWithValue("@idUtilisateur", idUtilisateur);
                insertCmd.Parameters.Add("@dateDemande", SqlDbType.DateTime).Value = DateTime.Now;
                insertCmd.Parameters.Add("@dateDebut", SqlDbType.DateTime).Value = dateDebut;
                insertCmd.Parameters.Add("@dateFin", SqlDbType.DateTime).Value = dateFin;

                int rowsAffected = insertCmd.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Demande d'emprunt effectuée avec succès !");
                }
                else
                {
                    MessageBox.Show("Aucune donnée n'a été insérée. Vérifiez les paramètres.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur lors de l'enregistrement de la demande : " + ex.Message);
            }
            finally
            {
                con.Close(); // Assurer la fermeture de la connexion
            }

            this.Hide();
            vos_demandes vos_demandes = new vos_demandes();
            vos_demandes.Show();
        }

        private void x_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
