﻿namespace Gestion_Materiels
{
    partial class Materiel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button2 = new System.Windows.Forms.Button();
            this.reserver = new System.Windows.Forms.Button();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.idequipementDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.categorieDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.etatDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statutDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.equipementsBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.gESTIONMATÉRIELSPORTIFDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gESTION_MATÉRIEL_SPORTIFDataSet = new Gestion_Materiels.GESTION_MATÉRIEL_SPORTIFDataSet();
            this.closeButton = new System.Windows.Forms.Label();
            this.infoLabel = new System.Windows.Forms.Label();
            this.equipementsTableAdapter = new Gestion_Materiels.GESTION_MATÉRIEL_SPORTIFDataSetTableAdapters.EquipementsTableAdapter();
            this.Dèconnection = new System.Windows.Forms.Button();
            this.equipementsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.equipementsBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gESTIONMATÉRIELSPORTIFDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gESTION_MATÉRIEL_SPORTIFDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.equipementsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(395, 277);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(93, 33);
            this.button2.TabIndex = 12;
            this.button2.Text = "Récapitulatif";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // reserver
            // 
            this.reserver.Location = new System.Drawing.Point(79, 277);
            this.reserver.Name = "reserver";
            this.reserver.Size = new System.Drawing.Size(100, 33);
            this.reserver.TabIndex = 11;
            this.reserver.Text = "reserver";
            this.reserver.UseVisualStyleBackColor = true;
            this.reserver.Click += new System.EventHandler(this.reserver_Click);
            // 
            // dataGridView
            // 
            this.dataGridView.AutoGenerateColumns = false;
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idequipementDataGridViewTextBoxColumn,
            this.nomDataGridViewTextBoxColumn,
            this.categorieDataGridViewTextBoxColumn,
            this.etatDataGridViewTextBoxColumn,
            this.statutDataGridViewTextBoxColumn,
            this.descriptionDataGridViewTextBoxColumn});
            this.dataGridView.DataSource = this.equipementsBindingSource1;
            this.dataGridView.Location = new System.Drawing.Point(40, 59);
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.RowHeadersWidth = 51;
            this.dataGridView.RowTemplate.Height = 24;
            this.dataGridView.Size = new System.Drawing.Size(804, 195);
            this.dataGridView.TabIndex = 10;
            this.dataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_CellContentClick);
            // 
            // idequipementDataGridViewTextBoxColumn
            // 
            this.idequipementDataGridViewTextBoxColumn.DataPropertyName = "id_equipement";
            this.idequipementDataGridViewTextBoxColumn.HeaderText = "id_equipement";
            this.idequipementDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.idequipementDataGridViewTextBoxColumn.Name = "idequipementDataGridViewTextBoxColumn";
            this.idequipementDataGridViewTextBoxColumn.ReadOnly = true;
            this.idequipementDataGridViewTextBoxColumn.Width = 125;
            // 
            // nomDataGridViewTextBoxColumn
            // 
            this.nomDataGridViewTextBoxColumn.DataPropertyName = "nom";
            this.nomDataGridViewTextBoxColumn.HeaderText = "nom";
            this.nomDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.nomDataGridViewTextBoxColumn.Name = "nomDataGridViewTextBoxColumn";
            this.nomDataGridViewTextBoxColumn.Width = 125;
            // 
            // categorieDataGridViewTextBoxColumn
            // 
            this.categorieDataGridViewTextBoxColumn.DataPropertyName = "categorie";
            this.categorieDataGridViewTextBoxColumn.HeaderText = "categorie";
            this.categorieDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.categorieDataGridViewTextBoxColumn.Name = "categorieDataGridViewTextBoxColumn";
            this.categorieDataGridViewTextBoxColumn.Width = 125;
            // 
            // etatDataGridViewTextBoxColumn
            // 
            this.etatDataGridViewTextBoxColumn.DataPropertyName = "etat";
            this.etatDataGridViewTextBoxColumn.HeaderText = "etat";
            this.etatDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.etatDataGridViewTextBoxColumn.Name = "etatDataGridViewTextBoxColumn";
            this.etatDataGridViewTextBoxColumn.Width = 125;
            // 
            // statutDataGridViewTextBoxColumn
            // 
            this.statutDataGridViewTextBoxColumn.DataPropertyName = "statut";
            this.statutDataGridViewTextBoxColumn.HeaderText = "statut";
            this.statutDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.statutDataGridViewTextBoxColumn.Name = "statutDataGridViewTextBoxColumn";
            this.statutDataGridViewTextBoxColumn.Width = 125;
            // 
            // descriptionDataGridViewTextBoxColumn
            // 
            this.descriptionDataGridViewTextBoxColumn.DataPropertyName = "description";
            this.descriptionDataGridViewTextBoxColumn.HeaderText = "description";
            this.descriptionDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.descriptionDataGridViewTextBoxColumn.Name = "descriptionDataGridViewTextBoxColumn";
            this.descriptionDataGridViewTextBoxColumn.Width = 125;
            // 
            // equipementsBindingSource1
            // 
            this.equipementsBindingSource1.DataMember = "Equipements";
            this.equipementsBindingSource1.DataSource = this.gESTIONMATÉRIELSPORTIFDataSetBindingSource;
            // 
            // gESTIONMATÉRIELSPORTIFDataSetBindingSource
            // 
            this.gESTIONMATÉRIELSPORTIFDataSetBindingSource.DataSource = this.gESTION_MATÉRIEL_SPORTIFDataSet;
            this.gESTIONMATÉRIELSPORTIFDataSetBindingSource.Position = 0;
            // 
            // gESTION_MATÉRIEL_SPORTIFDataSet
            // 
            this.gESTION_MATÉRIEL_SPORTIFDataSet.DataSetName = "GESTION_MATÉRIEL_SPORTIFDataSet";
            this.gESTION_MATÉRIEL_SPORTIFDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // closeButton
            // 
            this.closeButton.AutoSize = true;
            this.closeButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.closeButton.Location = new System.Drawing.Point(861, 9);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(21, 20);
            this.closeButton.TabIndex = 9;
            this.closeButton.Text = "X";
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // infoLabel
            // 
            this.infoLabel.AutoSize = true;
            this.infoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.infoLabel.Location = new System.Drawing.Point(170, 18);
            this.infoLabel.Name = "infoLabel";
            this.infoLabel.Size = new System.Drawing.Size(442, 20);
            this.infoLabel.TabIndex = 7;
            this.infoLabel.Text = "Bienvenue voici notre selection de matériels sportif";
            this.infoLabel.Click += new System.EventHandler(this.infoLabel_Click);
            // 
            // equipementsTableAdapter
            // 
            this.equipementsTableAdapter.ClearBeforeFill = true;
            // 
            // Dèconnection
            // 
            this.Dèconnection.Location = new System.Drawing.Point(665, 277);
            this.Dèconnection.Name = "Dèconnection";
            this.Dèconnection.Size = new System.Drawing.Size(112, 33);
            this.Dèconnection.TabIndex = 13;
            this.Dèconnection.Text = "Dèconnection";
            this.Dèconnection.UseVisualStyleBackColor = true;
            this.Dèconnection.Click += new System.EventHandler(this.Dèconnection_Click);
            // 
            // equipementsBindingSource
            // 
            this.equipementsBindingSource.DataMember = "Equipements";
            // 
            // Materiel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(894, 426);
            this.Controls.Add(this.Dèconnection);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.reserver);
            this.Controls.Add(this.dataGridView);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.infoLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Materiel";
            this.Text = "Materiel";
            this.Load += new System.EventHandler(this.Materiel_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.equipementsBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gESTIONMATÉRIELSPORTIFDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gESTION_MATÉRIEL_SPORTIFDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.equipementsBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button reserver;
        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.BindingSource equipementsBindingSource;
        private System.Windows.Forms.Label closeButton;
        private System.Windows.Forms.Label infoLabel;
        private System.Windows.Forms.BindingSource gESTIONMATÉRIELSPORTIFDataSetBindingSource;
        private GESTION_MATÉRIEL_SPORTIFDataSet gESTION_MATÉRIEL_SPORTIFDataSet;
        private System.Windows.Forms.BindingSource equipementsBindingSource1;
        private GESTION_MATÉRIEL_SPORTIFDataSetTableAdapters.EquipementsTableAdapter equipementsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idequipementDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn categorieDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn etatDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statutDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button Dèconnection;
    }
}