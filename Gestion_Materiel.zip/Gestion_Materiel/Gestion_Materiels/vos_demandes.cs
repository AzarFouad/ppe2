﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using Gestion_Materiel;

namespace Gestion_Materiels
{
    public partial class vos_demandes : Form
    {
        public vos_demandes()
        {
            InitializeComponent();
        }

        // Charger les demandes de la base de données
        private void vos_demandes_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'mATERIEL_SPORTIFDataSet1.Demandes'. Vous pouvez la déplacer ou la supprimer selon les besoins.
            this.demandesTableAdapter.Fill(this.mATERIEL_SPORTIFDataSet1.Demandes);
            LoadDemandes();
        }

        // Fonction pour charger les demandes depuis la base de données
        private void LoadDemandes()
        {
            // Créer la connexion à la base de données
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\USERS\FOUAD\ONEDRIVE\المستندات\MATERIEL_SPORTIF.MDF;Integrated Security=True;Connect Timeout=30");
            try
            {
                con.Open(); // Ouvrir la connexion à la base de données

                // Requête SQL pour récupérer les demandes
                string query = "SELECT id_demande, nom_equipement, date_demande, date_debut, date_fin, statut_demande FROM Demandes WHERE id_utilisateur = @idUtilisateur";

                // Créer un adaptateur pour récupérer les données
                SqlDataAdapter adapter = new SqlDataAdapter(query, con);
                adapter.SelectCommand.Parameters.AddWithValue("@idUtilisateur", Global.idutilisateur); // Utiliser l'ID de l'utilisateur global

                // Créer un DataTable pour stocker les résultats
                DataTable dt = new DataTable();
                adapter.Fill(dt); // Remplir le DataTable avec les données de la base

                if (dt.Rows.Count > 0)
                {
                    // Assigner le DataTable au DataGridView pour afficher les données
                    dataGridView1.DataSource = dt;
                }
                else
                {
                    MessageBox.Show("Aucune demande trouvée.");
                }
            }
            catch (Exception ex)
            {
                // Afficher une erreur si une exception survient
                MessageBox.Show("Erreur lors du chargement des demandes : " + ex.Message);
            }
            finally
            {
                // Fermer la connexion après l'opération
                con.Close();
            }
        }

        // Gérer l'événement de clic sur une ligne du DataGridView
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Vérifier si l'utilisateur a cliqué sur une ligne valide
            if (e.RowIndex >= 0)
            {
                // Récupérer les valeurs de la ligne sélectionnée
                var idDemande = dataGridView1.Rows[e.RowIndex].Cells["id_demande"].Value.ToString();
                var nomEquipement = dataGridView1.Rows[e.RowIndex].Cells["nom_equipement"].Value.ToString();
                var statutDemande = dataGridView1.Rows[e.RowIndex].Cells["statut_demande"].Value.ToString();

                // Afficher les détails de la demande 
                MessageBox.Show($"ID Demande: {idDemande}\nEquipement: {nomEquipement}\nStatut: {statutDemande}");

            }
        }

        // Retour à la page de connexion
        private void Dèconnection_Click(object sender, EventArgs e)
        {
            this.Hide();
            Connection connectionForm = new Connection();
            connectionForm.Show();
        }

        // Réservation d'un nouvel emprunt
        private void reserver_Click(object sender, EventArgs e)
        {
            this.Hide();
            Emprunts empruntsForm = new Emprunts();
            empruntsForm.Show();
        }

        private void x_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        
    }
}
