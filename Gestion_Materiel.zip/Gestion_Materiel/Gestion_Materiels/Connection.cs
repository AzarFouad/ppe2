﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using Gestion_Materiels;

namespace Gestion_Materiel
{
    // Classe statique pour les informations globales
    public static class Global
    {
        public static string Utilisateur { get; set; }
        public static int idutilisateur { get; set; } // Ajout de la variable pour l'ID utilisateur
        public static string Role { get; set; } // Ajout de la variable pour le rôle de l'utilisateur
    }

    // Formulaire de connexion
    public partial class Connection : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\USERS\FOUAD\ONEDRIVE\المستندات\MATERIEL_SPORTIF.MDF;Integrated Security=True;Connect Timeout=30");

        public Connection()
        {
            InitializeComponent();
        }

        private void RegisterButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Inscription FI = new Inscription();
            FI.Show();
        }

        private void Connection_Load(object sender, EventArgs e)
        {

        }

        private void x_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.Text;
                // Sélectionner aussi le rôle de l'utilisateur
                cmd.CommandText = "SELECT id_utilisateur, username, role FROM Utilisateurs WHERE username=@username AND mot_de_passe=@password";
                cmd.Parameters.AddWithValue("@username", UsernameBox.Text.Trim());
                cmd.Parameters.AddWithValue("@password", PasswordBox.Text.Trim());

                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);

                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("Nom d'utilisateur ou mot de passe incorrect.", "Erreur de connexion", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    Global.Utilisateur = dt.Rows[0]["username"].ToString();
                    Global.idutilisateur = Convert.ToInt32(dt.Rows[0]["id_utilisateur"]);
                    Global.Role = dt.Rows[0]["role"].ToString(); // Récupérer le rôle

                    MessageBox.Show($"Nom d'utilisateur connecté : {Global.Utilisateur}, ID utilisateur : {Global.idutilisateur}, Rôle : {Global.Role}", "Connexion réussie", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Vérification du rôle et redirection vers le formulaire approprié
                    this.Hide(); // Cache le formulaire de connexion

                    if (Global.Role == "admin")
                    {
                        // Si l'utilisateur est admin, ouvrir le formulaire Admin
                        Admin adminForm = new Admin();
                        adminForm.Show();
                    }
                    else
                    {
                        // Si l'utilisateur est un utilisateur normal, ouvrir le formulaire Materiel
                        Materiel materiel = new Materiel();
                        materiel.Show();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erreur : {ex.Message}", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                con.Close(); // Assure que la connexion est toujours fermée
            }
        }
    }
}
