﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Windows.Forms;
using Gestion_Materiel;

namespace Gestion_Materiels
{
    public partial class Materiel : Form
    {
        public Materiel()
        {
            InitializeComponent();
        }

        // Méthode pour charger les équipements avec le nom de la catégorie
        private void Equipements()
        {
            // Créer la connexion à la base de données
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\USERS\FOUAD\ONEDRIVE\المستندات\MATERIEL_SPORTIF.MDF;Integrated Security=True;Connect Timeout=30");

            try
            {
                con.Open(); // Ouvre la connexion à la base de données

                // Requête SQL pour récupérer les équipements et leur catégorie
                string query = @"
                    SELECT 
                        Equipements.id_equipement, 
                        Equipements.nom, 
                        categorie.nom_categorie AS categorie, 
                        Equipements.etat, 
                        Equipements.statut, 
                        Equipements.description 
                    FROM 
                        Equipements 
                    INNER JOIN 
                        categorie 
                    ON 
                        Equipements.id_categorie = categorie.id_categorie";

                // Créer un adaptateur pour récupérer les données
                SqlDataAdapter adapter = new SqlDataAdapter(query, con);

                // Créer un DataTable pour stocker les résultats
                DataTable dt = new DataTable();

                // Remplir le DataTable avec les données de la base de données
                adapter.Fill(dt);

                if (dt.Rows.Count > 0)
                {
                    // Assigner le DataTable au DataGridView pour afficher les données
                    dataGridView.DataSource = dt;

                    // Optionnel : Renommer les colonnes pour une meilleure lisibilité
                    dataGridView.Columns["id_equipement"].HeaderText = "ID Equipement"; 
                    dataGridView.Columns["nom"].HeaderText = "Nom Equipement";
                    dataGridView.Columns["categorie"].HeaderText = "Nom Catégorie";
                    dataGridView.Columns["etat"].HeaderText = "Etat";
                    dataGridView.Columns["statut"].HeaderText = "Statut";
                    dataGridView.Columns["description"].HeaderText = "Description";
                }
                else
                {
                    MessageBox.Show("Aucune donnée trouvée dans la base de données.");
                }
            }
            catch (Exception ex)
            {
                // Afficher un message d'erreur si une exception survient
                MessageBox.Show("Erreur lors de la connexion à la base de données : " + ex.Message);
            }
            finally
            {
                // Assure-toi de fermer la connexion
                con.Close();
            }
        }

        // Chargement du formulaire et appel de la méthode Equipements()
        private void Materiel_Load(object sender, EventArgs e)
        {
            // Mise à jour du texte du label avec le nom d'utilisateur lors du chargement du formulaire
            infoLabel.Text = $"Bienvenue, {Global.Utilisateur}! Voici notre sélection de matériels sportifs.";
            Equipements(); // Charger les équipements lors du chargement du formulaire
        }

        // Lorsqu'on clique sur une cellule du DataGridView
        private void dataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Vérifier si l'utilisateur a cliqué sur une ligne valide
            if (e.RowIndex >= 0)
            {
                // Récupérer le nom de l'équipement sélectionné
                var nomEquipement = dataGridView.Rows[e.RowIndex].Cells["nom"].Value.ToString();

                // Ouvrir le formulaire Emprunts avec l'élément sélectionné
                Emprunts empruntsForm = new Emprunts(nomEquipement);
                empruntsForm.Show();
                this.Hide();
            }
        }

        // Mettre à jour le texte du label infoLabel
        private void infoLabel_Click(object sender, EventArgs e)
        {
            infoLabel.Text = $"Bienvenue, {Global.Utilisateur}! Voici notre sélection de matériels sportifs.";
        }

        // Lors du clic sur le bouton de réservation
        private void reserver_Click(object sender, EventArgs e)
        {
            this.Hide();
            Emprunts empruntsForm = new Emprunts();
            empruntsForm.Show();
        }

        // Lors de la déconnexion
        private void Dèconnection_Click(object sender, EventArgs e)
        {
            this.Hide();
            Connection connectionForm = new Connection();
            connectionForm.Show();
        }

        // Lors du clic sur le bouton "Vos demandes"
        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            vos_demandes vos_demandes = new vos_demandes();
            vos_demandes.Show();
        }

        // Lors du clic sur le bouton de fermeture
        private void closeButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
