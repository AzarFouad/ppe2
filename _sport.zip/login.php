<?php 
include("header.php");
include 'connectBD.php';
include("menu.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $mot_de_passe = md5($_POST['mot_de_passe']);

    // Vérification de l'utilisateur dans la base de données
    $stmt = $conn->prepare("SELECT id_utilisateur, prenom, nom, email, is_active FROM utilisateur WHERE email = ? AND mot_de_passe = ?");
    $stmt->bind_param("ss", $email, $mot_de_passe);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id_utilisateur, $prenom, $nom, $email, $is_active);
        $stmt->fetch();

        if ($is_active) {
            // Création de la session utilisateur
            $_SESSION['Id_utilisateur'] = $id_utilisateur; // Ajout de l'ID utilisateur dans la session
            $_SESSION['prenom'] = $prenom;
            $_SESSION['nom'] = $nom;
            $_SESSION['email'] = $email;

            // Redirection vers la page d'accueil ou la dernière page visitée
            header("Location: ".$_SESSION['loc'].".php");
        } else {
            echo "<script>alert('Votre compte n\'est pas encore activé. Veuillez vérifier votre email pour activer votre compte.');</script>";
        }
    } else {
        echo "<script>alert('Email ou mot de passe incorrect.');</script>";
    }

    $stmt->close();
    $conn->close();
}
?>

<div class="form-container">
    <form action="login.php" method="POST">
        <h2>Connexion</h2>
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="mot_de_passe" placeholder="Mot de passe" required>
        <button type="submit">Se connecter</button>
        <input class="btninscription" type="button" onclick="window.location.href ='signup.php';" value="Pas de compte?" />
        <span><a href="forgot_password.php" class="psw">Mot de passe oublié?</a></span>
    </form>
</div>
<?php include("footer.php");?>
