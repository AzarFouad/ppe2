<?php
include("header.php");
include("connectBD.php");
include("menu.php");

// Vérification de la présence des paramètres token et expiration
if (isset($_GET['token']) && isset($_GET['expiration'])) { 
    $token = $conn->real_escape_string($_GET['token']);
    $expiration = intval($_GET['expiration']);

    // Vérifier si le lien a expiré
    if (time() >= $expiration) {
        echo "<script>alert('Ce lien a expiré. Veuillez demander une nouvelle réinitialisation.');</script>";
        echo "<script>window.location.href = 'forgot_password.php';</script>";
        exit;
    }

    // Vérifier si le token correspond à un utilisateur
    $sql = "SELECT Id_utilisateur FROM utilisateur WHERE SHA1(email) = '{$token}'";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $userId = $user['Id_utilisateur'];

        // Traitement du formulaire pour changer le mot de passe
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['password'], $_POST['confirm_password'])) {
            $password = $_POST['password'];
            $confirmPassword = $_POST['confirm_password'];

            // Validation du mot de passe
            $passwordErrors = [];
            if (strlen($password) < 8) {
                $passwordErrors[] = "Le mot de passe doit comporter au moins 8 caractères.";
            }
            if (!preg_match('/[A-Z]/', $password)) {
                $passwordErrors[] = "Le mot de passe doit contenir au moins une majuscule.";
            }
            if (!preg_match('/[a-z]/', $password)) {
                $passwordErrors[] = "Le mot de passe doit contenir au moins une minuscule.";
            }
            if (!preg_match('/[0-9]/', $password)) {
                $passwordErrors[] = "Le mot de passe doit contenir au moins un chiffre.";
            }
            if (!preg_match('/[\W]/', $password)) {
                $passwordErrors[] = "Le mot de passe doit contenir au moins un caractère spécial.";
            }

            if (!empty($passwordErrors)) {
                echo "<script>alert('Mot de passe non conforme :\\n" . implode("\\n", $passwordErrors) . "');</script>";
            } elseif ($password === $confirmPassword) {
                // Hashage sécurisé du mot de passe
                $hashedPassword = md5($password);

                // Mise à jour du mot de passe dans la base de données
                $sqlUpdate = "UPDATE utilisateur SET mot_de_passe = '{$hashedPassword}' WHERE Id_utilisateur = {$userId}";
                if ($conn->query($sqlUpdate) === TRUE) {
                    echo "<script>alert('Votre mot de passe a été modifié avec succès.');</script>";
                    echo "<script>window.location.href = 'login.php';</script>";
                    exit;
                } else {
                    echo "<script>alert('Erreur lors de la mise à jour du mot de passe.');</script>";
                }
            } else {
                echo "<script>alert('Les mots de passe ne correspondent pas.');</script>";
            }
        }
    } else {
        echo "<script>alert('Lien invalide ou utilisateur introuvable.');</script>";
        echo "<script>window.location.href = 'forgot_password.php';</script>";
        exit;
    }
} else {
    echo "<script>alert('Aucun token ou expiration fournis.');</script>";
    echo "<script>window.location.href = 'forgot_password.php';</script>";
    exit;
}
?>

<h2>Réinitialiser le mot de passe</h2>
<form action="reset_password.php?token=<?php echo htmlspecialchars($_GET['token']); ?>&expiration=<?php echo htmlspecialchars($_GET['expiration']); ?>" method="POST">
    <div class="form-container">
        <label for="password"><b>Nouveau mot de passe</b></label>
        <input type="password" placeholder="Entrez un nouveau mot de passe" name="password" required>
        <p><small > * Le mot de passe doit contenir au moins 8 caractères, une majuscule, une minuscule, un chiffre et un caractère spécial.</small></p>
        <label for="confirm_password"><b>Confirmez le mot de passe</b></label>
        <input type="password" placeholder="Confirmez votre mot de passe" name="confirm_password" required>

        <button type="submit">Réinitialiser le mot de passe</button>
    </div>
</form>
