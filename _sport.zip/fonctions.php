<?php
/*var Villes ={"Paris":{"lat":48.852962, "lon" : 2.349903},
            "Brest":{"lat":48.383, "lon" : -4.500},
            "Lyon":{"lat":45.759722, "lon" : 4.842222},
            "Marseille":{"lat":43.296944, "lon" : 5.369722},
            "Lille":{"lat":50.633056, "lon" : 3.050611}}
            ----------
            {"Complexe Sportif St-Symphorien": {"lat":49.12020000, "lon": 6.15678000},
            "Centre Sportif de Vandoeuvre": {"lat":48.67078900, "lon": 6.16845600},
            "Stade Marcel Picot": {"lat":48.69302800, "lon": 6.20732100},
            "Piscine Olympique d'Amnéville": {"lat":49.25701800, "lon": 6.13155400},
            "Palais des Sports Jean Weille": {"lat":48.68814000, "lon": 6.18341700},}
            
            */
function fliste_centres($conn){ //F
    //cette fonction va lire la liste des centres de la table centres de la base de donnee  puis les remplire dans un formormat de liste pour javascript
    $i=0;
    $liste="{";
    $result = $conn->query("SELECT * FROM centres");

    if ($result->num_rows > 0) { //I
        while ($row = $result->fetch_assoc()) { //w
            $i++;
            $liste=$liste.'"'.$row["Nom"].'": {"lat":'.$row["Lat"].', "lon": '.$row["Lon"].', "id": '.$row["Id_centre"].'}';
            if($i< $result->num_rows) $liste=$liste.",";
        }//W
    }//I
$liste=$liste."}";
return $liste;
}//F
?>