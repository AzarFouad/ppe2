<?php
include("header.php");
include("menu.php");
$_SESSION['loc'] = "inscription";
include("connectBD.php");

if (!isset($_SESSION['email'])) {
    header('Location: login.php'); // Rediriger vers la page de connexion si l'utilisateur n'est pas connecté
    exit();
} else {//1

    // Récupérer les informations de l'utilisateur connecté
    $Id_utilisateur = $_SESSION['Id_utilisateur'];
    $nom = $_SESSION['nom'];
    $prenom = $_SESSION['prenom'];
    $email = $_SESSION['email'];

    // Gestion de l'inscription au sport après confirmation
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['confirmed']) && $_POST['confirmed'] === 'yes') {//2

        $Id_centre = mysqli_real_escape_string($conn,$_POST['centre']);
        $Id_sport = mysqli_real_escape_string($conn,$_POST['sport']);
        $Date_demande = date('Y-m-d'); // Date actuelle
        $Annee = (date('m') >= 8 && date('m') <= 12) ? date('Y') : date('Y') + 1; // Inscription pour l'année en cours ou la prochaine

        // Insertion dans la table inscription_sport
        $sql = "INSERT INTO inscription_sport (Id_utilisateur, Id_centre, Id_sport, Date_demande, Annee) 
                VALUES ('$Id_utilisateur', '$Id_centre', '$Id_sport', '$Date_demande', '$Annee')";

        if ($conn->query($sql) === TRUE) {//3
            // Redirection vers la page "mes inscriptions"
            header('Location: mes_inscriptions.php');
            exit();
        } //3
        else {//3
            echo "Erreur lors de l'insertion : " . $conn->error;
        }//3
    }//2

    $Id_centre = isset($_SESSION['id']) ? intval($_SESSION['id']) : null;

    $centres_query = "SELECT Id_centre, Nom FROM centres";

    $centres_result = $conn->query($centres_query);

    // Récupérer les sports disponibles pour le centre sélectionné
    $sports_query = "SELECT Id_sport, Nom, Id_centre, Horaire_sport FROM sport";
    $sports_result = $conn->query($sports_query); 

?>

<div id="inscription-body">
<!--<div class="form-container">-->
    <form method="POST"  class="inscription_form" action="inscription.php?id=<?php echo $Id_centre; ?>" id="inscriptionForm">
        <h2>S'inscrire à un sport</h2>
        
        <!-- Affichage des informations utilisateur -->
        <label for="prénom">Prenom :</label>
        <input type="text" id="prenom" name="prenom" value="<?php echo htmlspecialchars($prenom); ?>" readonly="readonly"/>
        
        <label for="nom">Nom :</label>
        <input type="text" id="nom" name="nom" value="<?php echo htmlspecialchars($nom); ?>" readonly="readonly"/>
        
        <label for="mail">Email :</label>
        <input type="email" id="mail" name="mail" value="<?php echo htmlspecialchars($email); ?>" readonly="readonly"/>
        
        <!-- Choix du centre -->
        <label for="centre">Choisissez un centre :</label>
        <select name="centre" id="centre" required>
            <?php
            if ($centres_result->num_rows > 0) {
                while($row = $centres_result->fetch_assoc()) {
                    $selected = $row['Id_centre'] == $Id_centre ? 'selected' : '';
                    echo "<option value='" . $row['Id_centre'] . "' $selected>" . $row['Nom'] . "</option>";
                }
            } else {
                echo "<option>Aucun centre disponible</option>";
            }
            ?>
        </select>

        <!-- Choix du sport -->
        <label for="sport">Choisissez un sport :</label>
        <select name="sport" id="sport" required>
            <option value="" selected>Selectionnez un Sport</option>  <!-- Option pour afficher un message d'erreur -->

            <!-- Options des sports disponibles -->
            <?php
            if ($sports_result->num_rows > 0) {
                while($row = $sports_result->fetch_assoc()) {
                    echo "<option value='" . $row['Id_sport'] . "' data-centre='" . $row['Id_centre'] . "'>" . $row['Nom'] . " - " . $row['Horaire_sport'] . "</option>";
                }
            } else {
                echo "<option>Aucun sport disponible</option>";
            }
            ?>
        </select>
        
        <input type="hidden" name="confirmed" id="confirmed" value="no">
        <button type="button" onclick="confirmInscription()">S'inscrire</button>
    </form>
<!--</div>-->
 </div>
<script>
    // Script pour afficher uniquement les sports du centre sélectionné
    const centreSelect = document.getElementById('centre');
    const sportSelect = document.getElementById('sport');
    const sportsOptions = sportSelect.querySelectorAll('option');

    centreSelect.addEventListener('change', function() {
        const selectedCentre = this.value;
        sportsOptions.forEach(option => {
            option.style.display = option.getAttribute('data-centre') == selectedCentre ? 'block' : 'none';
        });
    });
    centreSelect.dispatchEvent(new Event('change'));

    function confirmInscription() {
        if (document.getElementById('sport').value != "") {
            const confirmation = confirm('Voulez-vous bien vous inscrire?');
            if (confirmation) {
                document.getElementById('confirmed').value = 'yes';
                alert('Votre inscription est bien pris en compte');
                document.forms['inscriptionForm'].submit();
  
                }
        } else {
            alert('Veuillez choisir un sport pour continuer');
        }
    }
</script>

<?php 
} // Fin de l'else
$conn->close();
include("footer.php");
?>
