<?php
include("header.php");
include("menu.php");

if (isset($_POST["prenom"])) {
    include 'connectBD.php';

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $prenom = mysqli_real_escape_string($conn,$_POST['prenom']);
        $nom = mysqli_real_escape_string($conn,$_POST['nom']);
        $email = mysqli_real_escape_string($conn,$_POST['email']);
        $mot_de_passe = mysqli_real_escape_string($conn,$_POST['mot_de_passe']);
        $confirm_mot_de_passe = mysqli_real_escape_string($conn,$_POST['confirm_mot_de_passe']);

        $error = '';
        
        // Vérification du mot de passe
        if ($mot_de_passe !== $confirm_mot_de_passe) {
            $error = 'Les mots de passe ne correspondent pas !';
        } elseif (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/', $mot_de_passe)) {
            $error = 'Le mot de passe doit contenir au moins 8 caractères, une majuscule, une minuscule, un chiffre et un caractère spécial.';
        } else {
            // Vérification si l'email existe déjà
            $stmt = $conn->prepare("SELECT email FROM utilisateur WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $stmt->store_result();

            if ($stmt->num_rows > 0) {
                $error = 'Un compte avec cet email existe déjà. Veuillez vous connecter avec cet email ou utiliser une autre adresse email pour vous inscrire.';
            } else {
                $token = bin2hex(random_bytes(50)); // Génère un token unique

                $stmt = $conn->prepare("INSERT INTO utilisateur (prenom, nom, email, mot_de_passe, token) VALUES (?, ?, ?, ?, ?)");
                $stmt->bind_param("sssss", $prenom, $nom, $email, md5($mot_de_passe), $token);

                if ($stmt->execute()) {
                    // Envoi de l'email d'activation
                    $link = "http://sport.fouadalazar.fr/activate.php?token=$token";
                    $subject = '=?UTF-8?B?'.base64_encode('Activation de compte').'?=';
                    $message = "Bonjour $prenom,\n\nCliquez sur le lien suivant pour activer votre compte : $link\n\nMerci.";
                    $headers = 'Content-Type: text/plain; charset=UTF-8' . "\r\n";
                    $headers .= 'From: info@fouadalazar.com' . "\r\n";

                    if (mail($email, $subject, $message, $headers)) {
                        echo "<script>alert('Un email d\'activation a été envoyé. Veuillez vérifier votre boîte de réception.'); window.location.href = 'login.php';</script>";
                    } else {
                        echo "<script>alert('Erreur lors de l\'envoi de l\'email d\'activation.');</script>";
                    }
                } else {
                    echo "Erreur : " . $stmt->error;
                }
            }

            $stmt->close();
        }

        $conn->close();

        if ($error != '') {
            echo "<script>alert('$error');</script>";
        }
    }
}
?>


<div class="form-container">
    <form action="signup.php" method="POST">
        <h2>Inscription</h2>
        <input type="text" name="prenom" placeholder="Prénom" <?php if (isset($_POST["prenom"])) {echo "value=".$_POST['prenom'];} ?> required>
        <input type="text" name="nom" placeholder="Nom" <?php if (isset($_POST['nom'])) {echo "value=".$_POST['nom'];} ?>required>
        <input type="email" name="email" placeholder="Email"<?php if (isset($_POST['email'])) {echo "value=".$_POST['email'];} ?> required>
        <input id="password" type="password" name="mot_de_passe" placeholder="Mot de passe*" required>
        <p><small > * Le mot de passe doit contenir au moins 8 caractères, une majuscule, une minuscule, un chiffre et un caractère spécial.</small></p>
        <input type="password" name="confirm_mot_de_passe" placeholder="Confirmer mot de passe" required>
        <button type="submit">S'inscrire</button>
    </form>
</div>
<?php include("footer.php"); ?>
