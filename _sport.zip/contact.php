
<?php
include("header.php");
include("menu.php");
if(isset($_POST['send'])){
    //extraction des variables
    extract($_POST);    
    //Verification si les variables existent et ne sont pas vides
    if(isset($username) && $username != "" &&
    isset($email) && $email != "" &&
    isset($phone) && $phone != "" &&
    isset($message) && $message != ""){
     //envoyer l'email
     //le destinataire (votre address mail)
            $to = "info@fouadalazar.fr";
            //objet du mail
            $subject = "Vous avez recu un message de : ". $email;
            
            $message = "
                <p>Vous avez recu un message de <strong>".$email."</stronge></p>
                <p><strong>Nom :</strong>".$username."</p>
                <p><strong>Téléphone :</strong>".$phone."</p>
                <p><strong>Message :</strong>".$message."</p>
            ";
            // Always set content-type when sending HTML email
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            
            // More headers
            $headers .= 'From: <'.$email.'>' . "\r\n";            
            //envoindu mail
           $send= mail($to,$subject,$message,$headers);
            //Verification de l'envoi
             if($send){
                $_SESSION['succes_message']="message envoyé";
             }
             else{
                $info="message non envoyé";
             }
            }
            else{
                //si elle sont vides
                $info = "Veuillez remplire tout les champs !";
            }
        }  

       

   ?>
    <div id="contact-body">
    <?php 
    //afficher le message d'erreur
    if(isset($info)){?>
        <p class="request_message" style="color:red">
            <?= $info?>  
        </p>
  <?php 
   }
       //afficher le message de succes
       if(isset($_SESSION['succes_message'])){?>
            <p class="request_message" style="color:green">
                <?= $_SESSION['succes_message']?>  
            </p>
      <?php 
       }
    ?>
    <form class="contact_form" action="" method="POST">
        <h2>Contact Us</h2>
        <label>Nom</label>
        <input type="text" name="username" >
        <label>Email</label>
        <input type="email" name="email" >
        <label>téléphone</label>
        <input type="tel" pattern="^((\+\d{1,3}(-| )?\(?\d\)?(-| )?\d{1,5})|(\(?\d{2,6}\)?))(-| )?(\d{3,4})(-| )?(\d{4})(( x| ext)\d{1,5}){0,1}$" name="phone">
        <label>Message</label>
       <textarea name="message" cols="30"rows="6" ></textarea>
       <button type="submit" name="send">ENVOYER</button>
    </form>
    </div>
<?php

include("footer.php");
?>