<?php
include("header.php");
include("menu.php");
$_SESSION['loc'] = "compte";
include("connectBD.php"); // Connexion à la base de données
// Vérification si l'utilisateur est connecté
if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['modification'])) {
    // Récupère les nouvelles valeurs des champs du formulaire
    $sql1 = "UPDATE utilisateur SET nom = '{$_POST['nom']}', prenom = '{$_POST['prenom']}',  email = '{$_POST['mail']}' WHERE Id_utilisateur = ".$_SESSION['Id_utilisateur'];

    if ($conn->query($sql1) === TRUE) {
        ?>
        <script>alert('Les informations ont été mises à jour avec succès.');</script>
        <?php
        } 
        else {
            ?>
            <script>alert('Erreur lors de la mise à jour.');</script>
            <?php
        }
}

//recuperation des informations
$sql= " SELECT * from utilisateur WHERE Id_utilisateur = ".$_SESSION['Id_utilisateur'].";";
$result = $conn->query($sql);

if ($result->num_rows > 0) { //if

    while ($row = $result->fetch_assoc()) { //w

        $nom = $row['nom'];
        $prenom = $row['prenom'];
        $email = $row['email'];


?>
    <div id="inscription-body"> 
    <form method="POST" id="inscriptionForm" action="compte.php">
    <h2>Profil  </h2>
             <!-- Affichage des informations utilisateur -->
             <label for="prenom">Prénom :</label>
             <input type="text" id="prenom" name="prenom" value="<?php echo htmlspecialchars($prenom); ?>" readonly/>
             
             <label for="nom">Nom :</label>
             <input type="text" id="nom" name="nom" value="<?php echo htmlspecialchars($nom); ?>" readonly/>
             
             <label for="mail">Email :</label>
             <input type="email" id="mail" name="mail" value="<?php echo htmlspecialchars($email); ?>" required/>  
            <button type="submit" name="modification">Modifier</button>
        </form>
        </div>
        <?php 
    }//w
    } //if
    $conn->close();
    include("footer.php");
    ?>