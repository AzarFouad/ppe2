
<footer>
<div class="container">
            <div class="footer-content"></br></br>
               <div class="addressefooter">Address 123 streetYour</div></br></br>
               <div class="telfooter"> 07 65 51 18 99</div>
            </div>
            <div class="footer-content">
                <h3>Accès rapide</h3>
                 <ul class="list">
                    <li><a href="index.php">Accueil</a></li>
                    <li><a href="./inscription.php">S'inscrire à un sport</a></li>
                    <li><a href="./contact.php">Contact</a></li>
                 </ul>
            </div>
            <div class="bottom-bar">
            <p>&copy; 2024 Tous droits réservés </br>Ce site web est fictif et a été créé à des fins éducatives uniquement. Les noms de centres et autres entités utilisés sur ce site sont mentionnés à titre d'illustration et ne sont pas associés à des institutions réelles</p>
           </div>
</footer>
</body>
</html>